package CountingWords;

public interface WordFrequency {
    String getWord();
    int getFrequency();
}
