package CountingWords;

public class Word implements WordFrequency{
    private String word;
    private int frequency;

    public Word(String word) {
        this.word = word;
        frequency = 1;
    }

    @Override
    public String getWord() {
        return word;
    }

    @Override
    public int getFrequency() {
        return frequency;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    @Override
    public String toString() {
        return "(\""+word + "\", " + frequency + ")";
    }
}
