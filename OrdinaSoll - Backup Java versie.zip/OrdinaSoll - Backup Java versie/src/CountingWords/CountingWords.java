package CountingWords;

public class CountingWords{

    public static void main(String[] args){
        WordFrequencyAnalyzerImpl analyzer = new WordFrequencyAnalyzerImpl();

        String text1 = "The sun shines over the lake";
        System.out.println(analyzer.calculateHighestFrequency(text1));                // 2
        System.out.println(analyzer.calculateFrequencyForWord(text1, "lake"));  // 1
        System.out.println(analyzer.calculateFrequencyForWord(text1,"zon"));    // 0
        System.out.println(analyzer.calculateMostFrequentNWords(text1, 3));       // [("the", 2), ("lake", 1), ("over", 1)]
        System.out.println(analyzer.calculateMostFrequentNWords(text1,0));        // []
        System.out.println(analyzer.calculateMostFrequentNWords(text1, 100));     // [("the", 2), ("lake", 1), ("over", 1), ("shines", 1), ("sun", 1)]

        String text2 = "The @sun718shInes_over   the#lake";                           // Test of regex goed werkt.
        System.out.println(analyzer.calculateHighestFrequency(text2));                // 1
        System.out.println(analyzer.calculateFrequencyForWord(text2, "lake"));   // 1
        System.out.println(analyzer.calculateMostFrequentNWords(text2, 3));        // [("the", 2), ("lake", 1), ("over", 1)]
    }
}
