package com.adillah.ordinarest;

import java.util.*;
import java.util.stream.Collectors;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

/* Deze REST app is ontwikkeld met Maven archetype jersey-quickstart-webapp in combinatie met Tomcat 10. Tomcat9 bleek incompatibel met deze jersey versie.
 URL begint met: "/webapi/"
 */

@Path("/wordcount")
public class WordFrequencyAnalyzerImpl implements WordFrequencyAnalyzer {

	@GET
	@Path("/maxfrequency/{text}")
	@Produces(MediaType.APPLICATION_JSON)
    @Override
    public int calculateHighestFrequency(@PathParam("text") String text) {		//Voorbeeld: http://localhost:8010/ordinarest/webapi/wordcount/maxfrequency/The%20sun%20shines%20over%20the%20lake
        List<Word> list = createListOfWords(text);  //Maak een List van Word objecten van de woorden in text.
        Word maxFreq = list.stream().max(Comparator.comparing(v -> v.getFrequency())).get();//Vindt het woord met de hoogste frequentie
        return maxFreq.getFrequency();

    }

	@GET
    @Path("/wordfrequency/{text}/{word}")
    @Produces({MediaType.APPLICATION_JSON})
    @Override
    public int calculateFrequencyForWord(@PathParam("text") String text, @PathParam("word") String word) {		//Voorbeeld: http://localhost:8010/ordinarest/webapi/wordcount/wordfrequency/The%20sun%20shines%20over%20the%20lake/the
        List<Word> list = createListOfWords(text);
        Word w = list.stream().filter(o -> o.getWord().equals(word)).findAny().orElse(null); // Selecteer Word object.
        if(w!=null){
            return w.getFrequency();
        }
        else{
            return 0; // Als word niet voorkomt in de text.
        }
    }

    @GET
    @Path("/mostfrequentwords/{text}/{n}")
    @Produces({MediaType.APPLICATION_JSON})
    @Override
    public List<WordFrequency> calculateMostFrequentNWords(@PathParam("text") String text, @PathParam("n") int n) {	//Voorbeeld: http://localhost:8010/ordinarest/webapi/wordcount/mostfrequentwords/The%20sun%20shines%20over%20the%20lake/3
    	List<Word> list = createListOfWords(text);

        Comparator<Word> comparator = new Comparator<Word>() {

            public int compare(Word o1, Word o2) {
                if ((o2.getFrequency() - o1.getFrequency()) != 0) {
                    return o2.getFrequency() - o1.getFrequency();   // Sorteer op frequentie
                } else {
                    return o1.getWord().compareTo(o2.getWord());    // Bij gelijke frequentie sorteer alfabetisch op String word veld
                }
            }
        };
        list.sort(comparator);
        List<WordFrequency> returnList = list.stream().limit(n).collect(Collectors.toList());// Limit het aantal Word Objecten tot n.
        
        return returnList;
    }


    public List<Word> createListOfWords(String text) {           // Maakt een List van Word Objecten met frequenties van een gegeven tekst.
        List<Word> list = new ArrayList<>();
        text = text.toLowerCase(Locale.ROOT);                    // Tekst naar lowercase
        String[] split = text.split("\\P{L}+");             // Split tekst in woorden met regex op alles dat geen letter is.

        for (String s : split) {
            if (list.stream().anyMatch(o -> o.getWord().equals(s))) {   // Check list of woord al aanwezig is.
                Word word = list.stream().filter(e -> e.getWord().equals(s)).findAny().orElse(null);//Als Word aanwezig: Selecteer Word Object
                word.setFrequency(word.getFrequency() + 1);       //En verhoog frequentie met 1
            } else {
                list.add(new Word(s));                            //Word is niet aanwezig in list: Voeg nieuw Word Object toe aan list
            }
        }
        return list;
    }
}
