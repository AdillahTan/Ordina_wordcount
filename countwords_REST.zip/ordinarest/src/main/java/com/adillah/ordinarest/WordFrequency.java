package com.adillah.ordinarest;

public interface WordFrequency {
    String getWord();
    int getFrequency();
}
